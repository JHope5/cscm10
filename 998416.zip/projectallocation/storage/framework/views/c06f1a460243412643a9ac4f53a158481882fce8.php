<?php use App\User;
      use App\Project;
      use App\Allocation; ?>



<?php $__env->startSection('title', 'Allocations'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-9">
            <h1>Project Allocations</h1>
        </div>
    </div>
    <div class="col-md-12">
        <hr>
    </div>
    <div class="pagination">
        <?php echo $allocations->links();; ?>

    </div>
    <div class="row">
        <div class="col-md-12">
            <table class="table">
                <thead>
                    <th>Student Number</th>
                    <th>Project Code</th>
                    <th>Project Name</th>
                    <th>Lecturer Email</th>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $allocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allocation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($allocation->student_number); ?> </td>
                            <td><?php echo e($allocation->project_code); ?></td>
                            <td><?php echo e($allocation->lecturer_name); ?></td>                       
                            <td><?php echo e($allocation->lecturer_email); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="pagination">
                <?php echo $allocations->links();; ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\masters-project\projectallocation\resources\views/projects/allocations.blade.php ENDPATH**/ ?>