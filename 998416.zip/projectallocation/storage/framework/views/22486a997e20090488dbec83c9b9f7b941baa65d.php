<?php use App\Project; 
      use App\User;
      use App\Student; ?>



<?php $__env->startSection('title', 'User Information'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-9">
        <?php if($user->role_id == 1 || $user->role_id == 2): ?>
        <h1><?php echo e($user->firstName . ' ' . $user->lastName); ?></h1>
        <?php else: ?>
        <h1><?php echo e($user->username); ?></h1>
        <?php endif; ?>
    </div>
    <div class="col-md-3">
        <?php if($user->role_id == 1 || $user->role_id == 2): ?>
        <?php echo Html::linkRoute('users.edit', 'Update Preferences', array($user->id), array('class'=>'btn btn-primary btn-block')); ?>

        <?php endif; ?>
        <?php if($user->role_id == 3): ?>
        <?php echo Html::linkRoute('students.edit', 'Edit', array($user->id), array('class'=>'btn btn-primary btn-block')); ?>

        <?php endif; ?>
    </div>
    <div class="col-md-12">
        <hr>
    </div>
</div>
<div class="row">
    <div class="col-md-9">
        <h3>Order of Preferences</h3>
        <hr>
        <?php if($user->role_id == 1 || $user->role_id == 2): ?>
        <table class="table">
                <thead>
                    <th>#</th>
                    <th>Student Number</th>
                    <th>Email</th>
                </thead>

                <tbody>
                    <?php $preferences = $user->preferences ?>
                    <?php $__currentLoopData = explode(' ', $preferences); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $preference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $student = Student::where('studentNumber', $preference)->first();
                          $studID = $student->id; ?>
                        <tr>
                            <th><?php echo e(Student::find($studID)->id); ?></th>
                            <td><?php echo e(Student::find($studID)->studentNumber); ?></td>
                            <td><?php echo e(Student::find($studID)->email); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <hr>
        <h3>Projects</h3>
        <table class="table">
                <thead>
                    <th>#</th>
                    <th>Name</th>
                    <th>Code</th>
                    <th>Description</th>
                    <th></th>
                </thead>

                <tbody>
                    <?php $projects = Project::get()->where('lecturer_id', $user->id); ?>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($project->id); ?></th>
                            <td><?php echo e($project->name); ?></td>
                            <td><?php echo e($project->code); ?></td>
                            <td><?php echo e(substr($project->description, 0, 50)); ?> <br> <?php echo e(strlen($project->content) > 50 ? Html::linkRoute('projects.show', 'Read More...', array($project->id)) : ""); ?></td>
                            <td><a href="<?php echo e(route('projects.show', $project->id)); ?>" class="btn btn-default btn-sm">View</a>
                                <?php if((Auth::id() == $project->lecturer_id) || (Auth::id() == 1)): ?>
                                <a href="<?php echo e(route('projects.edit', $project->id)); ?>" class="btn btn-default btn-sm">Edit</a>
                                <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php endif; ?>
            <?php if($user->role_id == 3): ?>
            <table class="table">
                <thead>
                    <th>#</th>
                    <th>Project Name</th>
                    <th>Lecturer</th>
                    <th>Lecturer Email</th>
                    <th></th>
                </thead>

                <tbody>
                    <?php $preferences = $user->preferences ?>
                    <?php $__currentLoopData = explode(' ', $preferences); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $preference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $proj = Project::where('code', $preference)->first();
                          $projID = $proj->id; ?>
                        <tr>
                            <th><?php echo e(Project::find($projID)->id); ?></th>
                            <td><?php echo e(Project::find($projID)->name); ?></td>
                            <td><?php echo e(User::find(Project::find($projID)->lecturer_id)->firstName . ' ' . User::find(Project::find($projID)->lecturer_id)->lastName); ?></td>
                            <td><?php echo e(User::find(Project::find($projID)->id)->email); ?></td>
                            <td><a href="<?php echo e(route('projects.show', Project::find($projID)->id)); ?>" class="btn btn-default btn-sm">View</a>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php endif; ?>
    </div>
    <div class="col-md-3">
            <div class="card bg-light mb-3" style="max-width: 18rem;">
                <div class="card-header">User Information</div>
                <div class="card-body">
                    <dl class="row">
                        <dt class="col-sm-12">User ID</dt>
                        <dd class="col-sm-12"><?php echo e($user->id); ?></dd>
                    </dl>
                    <dl class="row">
                        <?php if($user->role_id == 1 || $user->role_id == 2): ?>
                        <dt class="col-sm-12">Name</dt>
                        <dd class="col-sm-12"><?php echo e($user->firstName . ' ' . $user->lastName); ?></dd>
                        <?php endif; ?>
                        <?php if($user->role_id == 3): ?>
                        <dt class="col-sm-12">Student Number</dt>
                        <dd class="col-sm-12"><?php echo e($user->username); ?></dd>
                        <?php endif; ?>
                    </dl>
                    <dl class="row">
                        <dt class="col-sm-12">Email</dt>
                        <dd class="col-sm-12"><?php echo e($user->email); ?></dd>
                    </dl>
                </div>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\projectallocation\resources\views/users/show.blade.php ENDPATH**/ ?>