<?php use App\User;
      use App\Project; ?>



<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h1>All Users</h1>
        </div>
    </div>
    <div class="col-md-12">
        <hr>
    </div>
    <div class="row">
        <div class="col-md-12">
            <table class="table">
                <thead>
                    <th>#</th>
                    <th>Name</th>
                    <th>Contact</th>
                    <th></th>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if((User::find($user->id)->role_id == 1) || (User::find($user->id)->role_id == 2)): ?>
                        <tr>
                            <th><?php echo e($user->id); ?></th>
                            <th><?php echo e($user->name); ?> </th>
                            <td><?php echo e($user->email); ?></td>
                            <td><a href="<?php echo e(route('users.show', $user->id)); ?>" class="btn btn-default btn-sm">View Projects</a></td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\masters-project\projectallocation\resources\views/users/index.blade.php ENDPATH**/ ?>