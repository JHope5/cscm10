<?php use App\Project;
      use App\User; ?>



<?php $__env->startSection('title', 'Allocations'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <div class="jumbotron">
      <h1>Final Allocations</h1>
      <p class="lead">This is just a stub for now</p>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Laravel/projectallocation/resources/views/projects/allocations.blade.php ENDPATH**/ ?>