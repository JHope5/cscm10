<?php use App\Project; 
      use App\User;
      use App\Student; ?>



<?php $__env->startSection('title', 'Student Preferences'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-7">
        <h1><?php echo e($user->firstName . ' ' . $user->lastName); ?></h1>
        <hr>
        <h3>Order of Preferences</h3>
        <table class="table">
                <thead>
                    <th>#</th>
                    <th>Student Number</th>
                    <th>Email</th>
                </thead>

                <tbody>
                    <?php $preferences = $user->choices ?>
                    <?php $__currentLoopData = explode(' ', $preferences); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $preference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e(Student::find($preference)->id); ?></th>
                            <td><?php echo e(Student::find($preference)->studentNumber); ?></td>
                            <td><?php echo e(Student::find($preference)->email); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <hr>
    </div>
    <div class="col-md-5">
            <div class="card bg-light mb-3" style="max-width: 18rem;">
                    <div class="card-header">User Information</div>
                    <div class="card-body">
                      <dl class="row">
                          <dt class="col-sm-12">User ID</dt>
                          <dd class="col-sm-12"><?php echo e($user->id); ?></dd>
                      </dl>
                      <dl class="row">
                          <dt class="col-sm-12">Name</dt>
                          <dd class="col-sm-12"><?php echo e($user->name); ?></dd>
                      </dl>
                      <dl class="row">
                        <dt class="col-sm-12">Contact</dt>
                        <dd class="col-sm-12"><?php echo e($user->email); ?></dd>
                    </dl>
                    </div>
                  </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Laravel/projectallocation/resources/views/users/studpref.blade.php ENDPATH**/ ?>