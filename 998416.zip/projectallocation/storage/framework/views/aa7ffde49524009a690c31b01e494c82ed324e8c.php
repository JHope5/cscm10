<?php use App\User; ?>



<?php $__env->startSection('title', '- Edit Project'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-8">

        <!-- Helped with Laravel Collective
                https://laravelcollective.com/docs/6.0/html -->
        <?php echo Form::model($project, ['route' => ['projects.update', $project->id], 'method' => 'PUT', 'files' => true]); ?>

        <div class="col-md-8">
            <?php echo e(Form::label('name', 'Name:')); ?>

            <?php echo e(Form::text('name', null, ['class' => 'form-control input-lg'])); ?>

            <br>
            <?php echo e(Form::label('code', "Code:")); ?>

            <?php echo e(Form::text('code', null, ['class' => 'form-control'])); ?>

            <br>
            <?php echo e(Form::label('description', 'Description:')); ?>

            <?php echo e(Form::textarea('description', null, ['class' => 'form-control'])); ?> 
        </div>
    </div>
    <div class="col-md-4">
            <div class="card bg-light mb-3" style="max-width: 18rem;">
                    <div class="card-header">Project Information - <?php echo e($project->code); ?></div>
                    <div class="card-body">
                      <dl class="row">
                          <dt class="col-sm-6">Name</dt>
                          <dd class="col-sm-6"><?php echo e($project->name); ?></dd>
                      </dl>
                      <dl class="row">
                          <dt class="col-sm-6">Offered By</dt>
                          <dd class="col-sm-6"><a href="../../users/<?php echo e($project->lecturer_id); ?>"><?php echo e(User::find($project->lecturer_id)->firstName . ' ' . User::find($project->lecturer_id)->lastName); ?></a></dd>
                      </dl>
                      <dl class="row">
                          <dt class="col-sm-6">Created At</dt>
                          <dd class="col-sm-6"><?php echo e(date('F jS, Y H:i', strtotime($project->created_at))); ?></dd>
                      </dl>
                      <dl class="row">
                            <dt class="col-sm-6">Last Updated</dt>
                            <dd class="col-sm-6"><?php echo e(date('F jS, Y H:i', strtotime($project->updated_at))); ?></dd>
                        </dl>
                      <hr>
                      <div class="row">
                          <div class="col-sm-7">
                              <?php echo e(Form::submit('Save Changes', ['class' => 'btn btn-success btn-block'])); ?>

                          </div>
                          <div class="col-sm-5">
                              <?php echo Html::linkRoute('projects.show', 'Cancel', array($project->id), array('class' =>'btn btn-danger btn-block')); ?>

                          </div>
                          </div>
                      </div>
                    </div>
                  </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Laravel/projectallocation/resources/views/projects/edit.blade.php ENDPATH**/ ?>