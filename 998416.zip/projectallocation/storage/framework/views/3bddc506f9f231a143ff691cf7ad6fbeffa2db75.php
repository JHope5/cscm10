<?php use App\User;
      use App\Project; ?>



<?php $__env->startSection('title', 'Allocation'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-9">
            <h1>Students</h1>
        </div>
        <div class="col-md-3">
        <a href="<?php echo e(route('algorithm')); ?>" class="btn btn-lg btn-block btn-primary">Run Algorithm</a>
        </div>
    </div>
    <div class="col-md-12">
    <p>Students: <?php echo e($studentCount); ?>, Projects: <?php echo e($projectCount); ?>, Project spaces: <?php echo e($spaces); ?></p>
        <hr>
    </div>
    <div class="pagination">
        <?php echo $users->links();; ?>

    </div>
    <div class="row">
        <div class="col-md-12">
            <table class="table">
                <thead>
                    <th>#</th>
                    <th>Student Number</th>
                    <th>Contact</th>
                    <th>Choices</th>
                    <th></th>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(User::find($user->id)->role_id == 3): ?>
                        <tr>
                            <th><?php echo e($user->id); ?></th>
                            <td><?php echo e($user->username); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->preferences); ?></td>
                            <td><a href="<?php echo e(route('users.show', $user->id)); ?>" class="btn btn-default btn-sm">View</a>
                                <?php if(Auth::id() == 1): ?>
                                <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-default btn-sm">Edit</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="pagination">
                <?php echo $users->links();; ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\projectallocation\resources\views/projects/allocate.blade.php ENDPATH**/ ?>