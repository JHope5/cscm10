<?php use App\User;
      use App\Project; ?>



<?php $__env->startSection('title', 'Projects'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-9">
            <h1>All Projects</h1>
        </div>
        <div class="col-md-3">
        <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-lg btn-block btn-primary">Create New Project</a>
        </div>
    </div>
    <div class="col-md-12">
        <hr>
    </div>
    <div class="pagination">
        <?php echo $projects->links();; ?>

    </div>
    <div class="row">
        <div class="col-md-12">
            <table class="table">
                <thead>
                    <th>#</th>
                    <th>Project Name</th>
                    <th>Project Code</th>
                    <th>Offered By</th>
                    <th>Description</th>
                    <th></th>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($project->id); ?></th>
                            <td><?php echo e($project->name); ?> </td>
                            <td><?php echo e($project->code); ?></td>
                            <td><a href="<?php echo e(route('users.show', $project->lecturer_id)); ?>"><?php echo e(User::find($project->lecturer_id)->firstName . ' ' . User::find($project->lecturer_id)->lastName); ?></a></td>
                            <td><?php echo e(substr($project->description, 0, 50)); ?> <br> <?php echo e(strlen($project->description) > 50 ? Html::linkRoute('projects.show', 'Read More...', array($project->id)) : ""); ?></td>
                            <td><a href="<?php echo e(route('projects.show', $project->id)); ?>" class="btn btn-default btn-sm">View</a>
                                <?php if((Auth::id() == $project->lecturer_id) || (Auth::id() == 1)): ?>
                                <a href="<?php echo e(route('projects.edit', $project->id)); ?>" class="btn btn-default btn-sm">Edit</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="pagination">
                <?php echo $projects->links();; ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Laravel/projectallocation/resources/views/projects/index.blade.php ENDPATH**/ ?>