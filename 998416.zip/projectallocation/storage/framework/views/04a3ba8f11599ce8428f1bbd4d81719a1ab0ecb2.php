<?php use App\User;
      use App\Student;?>



<?php $__env->startSection('title', 'Update Preferences'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-9">

        <!-- Guided by Laravel Collective
                https://laravelcollective.com/docs/6.0/html -->
        <?php echo Form::model($user, ['route' => ['users.update', $user->id], 'method' => 'PUT']); ?>

        <div class="col-md-8">
            <?php echo e(Form::label('Preferences', 'Preferences:')); ?>

            <?php echo e(Form::textarea('preferences', null, ['class' => 'form-control'])); ?> 
            <?php echo e(Form::submit('Save Changes', ['class' => 'btn btn-success btn-block'])); ?>

            <?php echo Html::linkRoute('users.show', 'Cancel', array($user->id), array('class' =>'btn btn-danger btn-block')); ?>

        </div>
    </div>
    <div class="col-md-3">
    <div class="card bg-light mb-3" style="max-width: 18rem;">
                <div class="card-header">User Information</div>
                <div class="card-body">
                    <dl class="row">
                        <dt class="col-sm-12">User ID</dt>
                        <dd class="col-sm-12"><?php echo e($user->id); ?></dd>
                    </dl>
                    <dl class="row">
                        <dt class="col-sm-12">Name</dt>
                        <dd class="col-sm-12"><?php echo e($user->firstName . ' ' . $user->lastName); ?></dd>
                    </dl>
                    <dl class="row">
                        <dt class="col-sm-12">Email</dt>
                        <dd class="col-sm-12"><?php echo e($user->email); ?></dd>
                    </dl>
                </div>
            </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\projectallocation\resources\views/users/edit.blade.php ENDPATH**/ ?>