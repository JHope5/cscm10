<? use App\User; ?>

<!-- Navbar css -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="/">Home</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div id="navbarNavDropdown" class="navbar-collapse collapse">
      <ul class="navbar-nav mr-auto">
        <li class="<?php echo e(Request::segment(1) === 'projects' ? 'active' : null); ?>">
          <a class="nav-link" href="<?php echo e(url('/projects')); ?>">Projects</span></a>
        </li>
        <li class="<?php echo e(Request::segment(1) === 'users' ? 'active' : null); ?>">
          <a  class="nav-link" href="<?php echo e(url('/users')); ?>">Lecturers</a>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
      <?php if(auth()->guard()->guest()): ?>
        <li class="nav-item">
          <a class="nav-link" style="color:white" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
        </li>
        <?php if(Route::has('register')): ?>
        <li class="nav-item">
          <a class="nav-link" style="color:white" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
        </li>
        <?php endif; ?>
        <?php else: ?>
        <li class="nav-item dropdown">
          <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" 
              data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre style="color:white">
              <?php echo e(Auth::user()->username); ?> <span class="caret"></span>
          </a>
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="<?php echo e(route('users.show', Auth::id())); ?>">My Profile</a>
            <?php if(Auth::id() == 1): ?>
            <a class="dropdown-item" href="<?php echo e(route('allocate')); ?>">Allocate</a>
            <?php endif; ?>
            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                 document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?>

            </a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
              <?php echo csrf_field(); ?>
            </form>
          </div>
        </li>
      </ul>
      <?php endif; ?>
  </div>
</nav><?php /**PATH /home/vagrant/Laravel/projectallocation/resources/views/partials/_nav.blade.php ENDPATH**/ ?>