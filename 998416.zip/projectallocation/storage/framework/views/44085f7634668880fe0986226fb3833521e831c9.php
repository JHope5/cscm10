<?php use App\User; ?>



<?php $__env->startSection('title', 'Update Preferences'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-9">

        <!-- Helped with Laravel Collective
                https://laravelcollective.com/docs/6.0/html -->
        <?php echo Form::model($user, ['route' => ['updateprojectpreferences', $user->id]]); ?>

        <div class="col-md-8">
            <?php echo e(Form::label('Preferences', 'Preferences:')); ?>

            <?php echo e(Form::textarea('preferences', null, ['class' => 'form-control'])); ?> 
            <?php echo e(Form::submit('Save Changes', ['class' => 'btn btn-success btn-block'])); ?>

            <?php echo Html::linkRoute('users.show', 'Cancel', array($user->id), array('class' =>'btn btn-danger btn-block')); ?>

        </div>
    </div>
    <div class="col-md-3">
    <div class="card bg-light mb-3" style="max-width: 18rem;">
                <div class="card-header">User Information</div>
                <div class="card-body">
                    <dl class="row">
                        <dt class="col-sm-12">User ID</dt>
                        <dd class="col-sm-12"><?php echo e($user->id); ?></dd>
                    </dl>
                    <dl class="row">
                        <?php if($user->role_id == 1 || $user->role_id == 2): ?>
                        <dt class="col-sm-12">Name</dt>
                        <dd class="col-sm-12"><?php echo e($user->firstName . ' ' . $user->lastName); ?></dd>
                        <?php endif; ?>
                        <?php if($user->role_id == 3): ?>
                        <dt class="col-sm-12">Student Number</dt>
                        <dd class="col-sm-12"><?php echo e($user->username); ?></dd>
                        <?php endif; ?>
                    </dl>
                    <dl class="row">
                        <dt class="col-sm-12">Email</dt>
                        <dd class="col-sm-12"><?php echo e($user->email); ?></dd>
                    </dl>
                </div>
            </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Laravel/projectallocation/resources/views/users/updateprojectpreferences.blade.php ENDPATH**/ ?>